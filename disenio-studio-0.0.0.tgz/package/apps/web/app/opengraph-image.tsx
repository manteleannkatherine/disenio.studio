import { renderOg, OG_SIZE, OG_CONTENT_TYPE } from "./_lib/og";

export const runtime = "edge";
export const alt = "disenio.studio — a copy-paste design toolkit";
export const size = OG_SIZE;
export const contentType = OG_CONTENT_TYPE;

export default function OgImage() {
  return renderOg({
    title: (
      <>
        <span>A design toolkit with a</span>
        <span
          style={{
            background:
              "linear-gradient(135deg, #b27bff 0%, #6d4cf2 50%, #2f5dff 100%)",
            backgroundClip: "text",
            color: "transparent",
            fontStyle: "italic",
          }}
        >
          feel.
        </span>
      </>
    ),
    meta: ["13 components", "9 pairs", "6 feels", "cli"],
  });
}
